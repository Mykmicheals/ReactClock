import React, { useState } from "react";

function App() {
  const [time, setTime] = useState()
  setInterval(updateTime, 1000)

  function updateTime() {
    const latestTime = new Date().toLocaleTimeString();
    setTime(latestTime)
  }
  return (
    <div className="container">
      <h3>{time}</h3>

    </div>
  );
}

export default App;